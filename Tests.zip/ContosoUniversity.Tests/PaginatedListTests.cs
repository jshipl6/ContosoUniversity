﻿// Adjust to wherever your PaginatedList<T> lives:
using ContosoUniversity.Infrastructure;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ContosoUniversity.Tests;

public class PaginatedListTests
{
    private sealed class TestContext : DbContext
    {
        public TestContext(DbContextOptions<TestContext> options) : base(options) { }
        public DbSet<NumberRow> Numbers => Set<NumberRow>();
    }

    private sealed class NumberRow
    {
        public int Id { get; set; }
        public int Value { get; set; }
    }

    private static async Task<TestContext> BuildContextWith10Async()
    {
        var options = new DbContextOptionsBuilder<TestContext>()
            .UseInMemoryDatabase($"paginated-tests-{Guid.NewGuid()}")
            .Options;

        var db = new TestContext(options);
        for (int i = 1; i <= 10; i++)
            db.Numbers.Add(new NumberRow { Value = i });
        await db.SaveChangesAsync();
        return db;
    }

    [Fact]
    public async Task CreateAsync_Computes_Paging_Flags()
    {
        await using var db = await BuildContextWith10Async();

        var query = db.Numbers.AsNoTracking().OrderBy(n => n.Value).Select(n => n.Value);
        var page = await PaginatedList<int>.CreateAsync(query, pageIndex: 2, pageSize: 3);

        page.PageIndex.Should().Be(2);
        page.TotalPages.Should().Be((int)Math.Ceiling(10 / 3.0));
        page.HasPreviousPage.Should().BeTrue();
        page.HasNextPage.Should().BeTrue();
    }

    [Fact]
    public async Task CreateAsync_Returns_Correct_Items_For_Page()
    {
        await using var db = await BuildContextWith10Async();

        var query = db.Numbers.AsNoTracking().OrderBy(n => n.Value).Select(n => n.Value);
        var page2 = await PaginatedList<int>.CreateAsync(query, pageIndex: 2, pageSize: 3);

        page2.Should().BeEquivalentTo(new[] { 4, 5, 6 }, o => o.WithStrictOrdering());
    }
}
