﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ContosoUniversity.Data;

namespace ContosoUniversity.Tests
{
    public sealed class CustomWebAppFactory : WebApplicationFactory<Program>
    {
        private SqliteConnection? _keepAlive;

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Development");

            builder.ConfigureServices(services =>
            {
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<SchoolContext>));

                if (descriptor is not null)
                    services.Remove(descriptor);

                _keepAlive ??= new SqliteConnection("Data Source=file:tests.db;Mode=Memory;Cache=Shared");
                if (_keepAlive.State != System.Data.ConnectionState.Open)
                    _keepAlive.Open();

                services.AddDbContext<SchoolContext>(options =>
                {
                    options.UseSqlite(_keepAlive);
                });

                var sp = services.BuildServiceProvider();

                using var scope = sp.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<SchoolContext>();

                db.Database.EnsureDeleted();
            });
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                _keepAlive?.Dispose();
                _keepAlive = null;
            }
        }
    }
}
