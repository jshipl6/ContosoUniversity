﻿using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace ContosoUniversity.Tests;

public class StudentsPageTests : IClassFixture<CustomWebAppFactory>
{
    private readonly CustomWebAppFactory _factory;

    public StudentsPageTests(CustomWebAppFactory factory) => _factory = factory;

    [Fact]
    public async Task Get_Students_Index_Returns_Ok_And_Html()
    {
        var client = _factory.CreateClient();
        var resp = await client.GetAsync("/Students");
        Assert.Equal(HttpStatusCode.OK, resp.StatusCode);

        var html = await resp.Content.ReadAsStringAsync();
        Assert.Contains("Students", html);
    }
}
